

def ses_handler(event, context):
    for record in event["Records"]:
        print(record["body"])
